<div class="page">
    <h2>Tentang Wulan Maulidya(Diri Saya)</h2>
    <p> Lahir di Jakarta.<br>
        Tanggal lahir 13 mei 2003.<br>
        Jenis Kelamin Perempuan.<br> 
        Agama Islam.<br>
        Kewarganegaraan Indonesia.<br>
        Sekarang saya Tinggal di Banyuwangi, Jawa Timur.<br>
        Hobi saya Menonton Drakor, Anime dan Film serta mendengarkan musik.<br>
        </br></p>
</div>
