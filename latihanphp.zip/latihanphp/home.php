<div class="page">
    <h2>Wulan Maulidya</h2>
    <p>Saya adalah salah satu mahasiswa Telkom University dari jurusan D3 Rekayasa Perangkat Lunak, Angkatan 45, dan kelas 03.</p>
</div>
