<div class="page">
    <h2>Contact Me</h2>
    <p>Telp: 087863825566
        <br>WA: 0895395186038
        <br>Email:maulidyawulan@365.studenttelkomuniversity.ac.id</br></p>
 
    <p>Alamat Kos di Bandung: <br>
    Kos Pondok Larissa Lengkong, Bojongsoang, Bandung, Jawa Barat.</br></p>
</div>